"""
CTE (Common Table Expression) extraction and analysis tool.

This module defines the CTEExtractor class, which extracts and analyzes
CTE definitions from WITH clauses in SQL queries.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import sqlglot
from sqlglot import exp

from lineage_analyzer.analyzer.dependency_extractor import DependencyExtractor
from lineage_analyzer.analyzer.scope_builder import ScopeBuilder
from lineage_analyzer.analyzer.symbol_resolver import SymbolResolver
from lineage_analyzer.models.column_lineage import ColumnLineage
from lineage_analyzer.models.config import LineageConfig
from lineage_analyzer.models.table_definition import TableDefinition, TableType
from lineage_analyzer.registry.table_registry import TableRegistry
from lineage_analyzer.schema.provider import SchemaProvider


class CTEDefinition:
    """CTE definition."""

    def __init__(self, name: str, select_node: exp.Select):
        self.name = name
        self.select_node = select_node

    def __repr__(self):
        return f"CTE({self.name})"


class CTEExtractor:
    """
    CTE extractor.

    Responsibilities:
    1. Extract CTE definitions from SELECT statements
    2. Analyze CTE's SELECT statements
    3. Register CTEs as temporary tables

    Usage:
        extractor = CTEExtractor(registry, config, schema_provider)
        ctes = extractor.extract_ctes(select_node)
        extractor.analyze_and_register_ctes(ctes)
    """

    def __init__(
        self,
        registry: TableRegistry,
        config: LineageConfig,
        schema_provider: Optional[SchemaProvider] = None,
    ):
        """
        Args:
            registry: Table registry
            config: Lineage configuration
            schema_provider: Optional schema provider
        """
        self.registry = registry
        self.config = config
        self.schema_provider = schema_provider

    def extract_ctes(self, select_node: exp.Select) -> List[CTEDefinition]:
        """
        Extract all CTE definitions from a SELECT node.

        Args:
            select_node: SELECT statement AST node

        Returns:
            List[CTEDefinition]: CTE definition list (in definition order)

        Example:
            WITH tmp1 AS (...), tmp2 AS (...)
            Returns: [CTE(tmp1), CTE(tmp2)]
        """
        ctes = []

        # Check if there is a WITH clause
        with_node = select_node.args.get("with")
        if not with_node:
            return ctes

        # Traverse all CTE expressions
        for cte_expr in with_node.expressions:
            # CTE structure:
            # CTE(
            #     alias=...,     # CTE name
            #     this=Select()  # CTE's SELECT statement
            # )
            if isinstance(cte_expr, exp.CTE):
                cte_name = cte_expr.alias
                cte_select = cte_expr.this

                if cte_name and isinstance(cte_select, exp.Select):
                    ctes.append(CTEDefinition(cte_name, cte_select))

        return ctes

    def analyze_and_register_ctes(
        self, ctes: List[CTEDefinition], statement_index: int = 0
    ) -> Dict[str, TableDefinition]:
        """
        Analyze and register CTE tables.

        Key points:
        1. Analyze in order (later CTEs may reference earlier ones)
        2. Use existing DependencyExtractor to analyze SELECT
        3. Register as TableType.CTE

        Args:
            ctes: CTE definition list
            statement_index: Statement index (for recording)

        Returns:
            Dict[str, TableDefinition]: CTE name -> table definition
        """
        registered_ctes = {}

        for cte in ctes:
            try:
                # 1. Build scope for CTE's SELECT
                # CTE can reference earlier CTEs (already in registry)
                scope_builder = ScopeBuilder(
                    config=self.config,
                    schema_provider=self.schema_provider,
                    registry=self.registry,
                )
                scope = scope_builder.build_scope(cte.select_node)

                # 2. Auto-register source tables from scope to registry
                # This ensures source tables are available for transitive resolution
                for table_ref in scope.tables.values():
                    table_name = table_ref.table
                    # Only register if not already in registry
                    if not self.registry.has_table(table_name):
                        # Try to get columns from schema provider
                        if self.schema_provider:
                            try:
                                columns = self.schema_provider.get_table_columns(
                                    table_ref.to_qualified_name()
                                )
                                self.registry.register_source_table(table_name, columns)
                            except Exception:
                                # Schema doesn't have this table, register without columns
                                self.registry.register_source_table(table_name)
                        else:
                            # No schema provider, register without columns
                            self.registry.register_source_table(table_name)

                # 3. Create Symbol Resolver
                resolver = SymbolResolver(scope, self.config, self.schema_provider)

                # 4. Extract dependencies (using DependencyExtractor)
                extractor = DependencyExtractor(scope, resolver, self.config)
                dependencies = extractor.extract(cte.select_node)

                # 5. Convert ColumnDependency to ColumnLineage
                column_lineages = self._convert_dependencies_to_lineages(dependencies)

                # 6. Convert to ColumnLineage dictionary
                columns = {}
                for lineage in column_lineages:
                    columns[lineage.name] = lineage

                # 7. Create CTE table definition
                cte_table = TableDefinition(
                    name=cte.name,
                    table_type=TableType.CTE,
                    columns=columns,
                    created_at_statement=statement_index,
                )

                # 8. Register to Registry
                self.registry.register_table(cte_table)
                registered_ctes[cte.name] = cte_table

            except Exception as e:
                # If CTE analysis fails, log but continue
                # This prevents one CTE failure from breaking the entire statement
                print(f"Warning: Failed to analyze CTE '{cte.name}': {e}")
                continue

        return registered_ctes

    def _convert_dependencies_to_lineages(
        self, dependencies: List
    ) -> List[ColumnLineage]:
        """Convert ColumnDependency list to ColumnLineage list.

        This method groups dependencies by target column and merges
        all sources for each target.

        Args:
            dependencies: List of ColumnDependency objects

        Returns:
            List[ColumnLineage]: Deduplicated and merged column lineages
        """
        from collections import defaultdict

        # Group by target column
        grouped: Dict[str, List] = defaultdict(list)
        for dep in dependencies:
            target_name = dep.target.column
            grouped[target_name].append(dep)

        # Build ColumnLineage for each target column
        lineages = []
        for target_name, deps in grouped.items():
            # Collect all source columns
            sources = []
            for dep in deps:
                sources.append(dep.source)

            # Extract expression (use first dependency's expression)
            expression = deps[0].expression if deps else None
            expression_type = deps[0].expression_type if deps else None
            confidence = deps[0].confidence if deps else 1.0

            # Create ColumnLineage
            lineage = ColumnLineage(
                name=target_name,
                sources=sources,
                expression=expression,
                expression_type=expression_type,
                confidence=confidence,
            )

            lineages.append(lineage)

        return lineages

    def has_ctes(self, select_node: exp.Select) -> bool:
        """
        Check if SELECT statement contains CTEs.

        Args:
            select_node: SELECT statement node

        Returns:
            bool: Whether there are CTEs
        """
        return select_node.args.get("with") is not None

