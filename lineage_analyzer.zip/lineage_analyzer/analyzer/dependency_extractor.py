"""
Dependency extractor for lineage analysis.

This module defines the DependencyExtractor class, which extracts
field-level dependencies from SELECT statements.
"""

from __future__ import annotations

import re
from typing import Optional

import sqlglot
from sqlglot import expressions

from lineage_analyzer.analyzer.expression_visitor import ExpressionVisitor
from lineage_analyzer.analyzer.symbol_resolver import SymbolResolver
from lineage_analyzer.exceptions import LineageError
from lineage_analyzer.models.column import ColumnRef
from lineage_analyzer.models.config import ErrorMode, LineageConfig
from lineage_analyzer.models.dependency import ColumnDependency, ExpressionType
from lineage_analyzer.models.scope import Scope
from lineage_analyzer.utils.ast_utils import get_select_expressions
from lineage_analyzer.utils.expression_utils import (
    contains_binary_op,
    contains_function,
    deduplicate_columns,
    is_aggregate_function,
    is_window_function,
)


class DependencyExtractor:
    """Extracts field-level dependencies from SELECT statements.

    This class extracts field-level dependencies from SELECT statements,
    tracking which source columns contribute to which target columns.

    Attributes:
        scope: Scope object containing table and column information.
        resolver: SymbolResolver used to resolve column references.
        config: LineageConfig object containing extractor configuration.
        dependencies: List of ColumnDependency objects extracted.

    Example:
        >>> extractor = DependencyExtractor(scope, resolver, config)
        >>> dependencies = extractor.extract(ast)
        >>> len(dependencies) > 0
        True
    """

    def __init__(
        self,
        scope: Scope,
        resolver: SymbolResolver,
        config: LineageConfig,
    ) -> None:
        """Initialize a DependencyExtractor.

        Args:
            scope: Scope object containing table and column information.
            resolver: SymbolResolver used to resolve column references.
            config: LineageConfig object containing extractor configuration.
        """
        self.scope = scope
        self.resolver = resolver
        self.config = config
        self.dependencies: list[ColumnDependency] = []

    def extract(
        self, ast: sqlglot.Expression
    ) -> list[ColumnDependency]:
        """Extract all field dependencies from AST.

        This is the main entry point for extracting dependencies from
        a SELECT statement AST. It processes all SELECT expressions and
        creates ColumnDependency objects for each source-target pair.

        Main workflow:
        1. Get SELECT list
        2. Iterate over each SELECT expression
        3. Extract expression dependencies (source columns)
        4. Determine target column name (considering aliases)
        5. Determine expression type
        6. Get original expression text (for traceability)
        7. Create ColumnDependency objects for each source-target pair

        Args:
            ast: sqlglot SELECT statement AST.

        Returns:
            List of ColumnDependency objects.

        Raises:
            NotImplementedError: If unsupported features are encountered
                (aggregate functions, window functions).

        Example:
            >>> extractor = DependencyExtractor(scope, resolver, config)
            >>> dependencies = extractor.extract(ast)
            >>> len(dependencies) > 0
            True
        """
        self.dependencies = []

        # === Complexity check ===
        from lineage_analyzer.utils.complexity import (
            ComplexityAnalyzer,
            check_complexity_limits,
        )

        complexity_analyzer = ComplexityAnalyzer()
        metrics = complexity_analyzer.analyze_select_statement(ast)

        # Check if limits are exceeded
        is_valid, error_msg = check_complexity_limits(
            metrics,
            max_nodes=self.config.max_expression_nodes,
            max_depth=self.config.max_expression_depth,
            max_case_branches=self.config.max_case_branches,
        )

        if not is_valid:
            if self.config.on_complexity_exceeded == ErrorMode.FAIL:
                from lineage_analyzer.exceptions import LineageError

                raise LineageError(f"Complexity check failed: {error_msg}")
            elif self.config.on_complexity_exceeded == ErrorMode.WARN:
                self.resolver.warnings.add(
                    "WARNING",
                    f"High complexity detected: {error_msg}",
                    context=ast.sql() if hasattr(ast, "sql") else None,
                )

        # Record complexity metrics (for debugging and monitoring)
        if self.config.on_complexity_exceeded != ErrorMode.IGNORE:
            self.resolver.warnings.add(
                "INFO",
                f"Expression complexity: {metrics.total_nodes} nodes, "
                f"{metrics.max_depth} max depth, {metrics.num_columns} columns, "
                f"{metrics.num_functions} functions, {metrics.num_case_branches} CASE branches",
                context=None,
            )

        # === Continue with original logic ===
        # Get SELECT expressions
        select_expressions = get_select_expressions(ast)

        for expr in select_expressions:
            # Check if this is a Star expression (SELECT * or SELECT table.*)
            is_star = self._is_star_expression(expr)
            
            if is_star:
                # Handle SELECT * or SELECT table.*
                # Get table qualifier if it's SELECT table.*
                table_qualifier = None
                if isinstance(expr, expressions.Column) and expr.table:
                    # Extract table qualifier from Identifier or string
                    if isinstance(expr.table, expressions.Identifier):
                        table_qualifier = expr.table.name
                    elif isinstance(expr.table, str):
                        table_qualifier = expr.table
                    elif hasattr(expr.table, "this"):
                        table_qualifier = expr.table.this
                
                # Resolve star column
                if hasattr(self.resolver, "resolve_star_column"):
                    star_columns = self.resolver.resolve_star_column(table_qualifier)
                    # Create a dependency for each column from the star
                    for source_col in star_columns:
                        # Target column name is the column name itself
                        target_col = ColumnRef(
                            table="__OUTPUT__",
                            column=source_col.column,
                            alias=None,
                        )
                        
                        # Get confidence for this column
                        confidence = 1.0  # Default confidence for schema-resolved columns
                        if hasattr(self.resolver, "resolve_column_with_inference"):
                            try:
                                _, confidence = self.resolver.resolve_column_with_inference(
                                    source_col.column,
                                    source_col.table,
                                    expr.sql() if hasattr(expr, "sql") else None,
                                )
                            except Exception:
                                confidence = 1.0
                        
                        dependency = ColumnDependency(
                            source=source_col,
                            target=target_col,
                            expression_type=ExpressionType.DIRECT,
                            expression=f"{source_col.table}.{source_col.column}",
                            confidence=confidence,
                        )
                        self.dependencies.append(dependency)
                # If resolver doesn't support star columns, skip
            else:
                # Regular expression handling
                # 1. Determine target column name
                target_name = self._get_target_column_name(expr)

                # 2. Extract source columns with confidence
                source_columns_conf = self._extract_source_columns_with_confidence(expr)

                # 3. Determine expression type
                expr_type = self._determine_expression_type(expr)

                # 4. Get original expression text (formatted)
                expression_text = self._get_expression_text(expr)

                # 5. Create dependency for each source column
                for source_col, confidence in source_columns_conf.items():
                    target_col = ColumnRef(
                        table="__OUTPUT__",  # Output columns use special table name
                        column=target_name,
                        alias=None,
                    )

                    dependency = ColumnDependency(
                        source=source_col,
                        target=target_col,
                        expression_type=expr_type,
                        expression=expression_text,
                        confidence=confidence,
                    )

                    self.dependencies.append(dependency)

        return self.dependencies

    def _get_select_expressions(
        self, ast: sqlglot.Expression
    ) -> list[sqlglot.Expression]:
        """Get all expressions from SELECT clause.

        This method extracts all expressions from the SELECT clause
        of a SELECT statement AST.

        Args:
            ast: sqlglot SELECT statement AST.

        Returns:
            List of sqlglot expression nodes from SELECT clause.

        Example:
            >>> extractor = DependencyExtractor(scope, resolver, config)
            >>> exprs = extractor._get_select_expressions(ast)
            >>> len(exprs) > 0
            True
        """
        return get_select_expressions(ast)

    def _get_target_column_name(self, expr: sqlglot.Expression) -> str:
        """Determine the name of the target column.

        This method determines the name of the target column based on:
        1. If there's an AS alias, use the alias
        2. If it's a simple column reference (SELECT col), use the column name
        3. If it's a complex expression without an alias, generate a name
           (e.g., "expr_1") or use the original SQL

        Args:
            expr: SELECT expression node.

        Returns:
            Target column name.

        Example:
            >>> extractor = DependencyExtractor(scope, resolver, config)
            >>> alias_node = sqlglot.parse_one("SELECT id AS user_id").expressions[0]
            >>> name = extractor._get_target_column_name(alias_node)
            >>> name == "user_id"
            True
        """
        # Check for alias
        if isinstance(expr, expressions.Alias):
            alias = expr.alias
            if isinstance(alias, expressions.Identifier):
                return alias.name
            elif isinstance(alias, str):
                return alias
            # Fallback: get alias from args
            if hasattr(expr, "args") and "alias" in expr.args:
                alias_val = expr.args["alias"]
                if isinstance(alias_val, expressions.Identifier):
                    return alias_val.name
                elif isinstance(alias_val, str):
                    return alias_val

        # Check for simple column reference
        if isinstance(expr, expressions.Column):
            return expr.name

        # Complex expression without alias: use SQL text or generate name
        if hasattr(expr, "sql"):
            sql_text = expr.sql()
            # Normalize whitespace
            sql_text = re.sub(r"\s+", " ", sql_text).strip()
            return sql_text

        return "unnamed_expr"

    def _extract_source_columns(
        self, expr: sqlglot.Expression
    ) -> list[ColumnRef]:
        """Extract all source columns from an expression.

        This method uses ExpressionVisitor to extract all column
        dependencies from an expression. It deduplicates the results
        (same column appearing multiple times only generates one dependency).

        Args:
            expr: SELECT expression node.

        Returns:
            List of unique ColumnRef objects (deduplicated).

        Example:
            >>> extractor = DependencyExtractor(scope, resolver, config)
            >>> add_node = sqlglot.parse_one("SELECT a + b").expressions[0]
            >>> columns = extractor._extract_source_columns(add_node)
            >>> len(columns) >= 2
            True
        """
        visitor = ExpressionVisitor(self.resolver, debug=False)
        columns = visitor.visit(expr)

        # Deduplicate (same column appearing multiple times)
        return deduplicate_columns(columns)

    def _extract_source_columns_with_confidence(
        self, expr: sqlglot.Expression
    ) -> dict[ColumnRef, float]:
        """Extract all source columns from an expression with confidence scores.

        This enhanced method extracts columns and their confidence scores
        from an expression. It deduplicates columns and returns the maximum
        confidence for each unique column.

        Args:
            expr: SELECT expression node.

        Returns:
            Dictionary mapping ColumnRef to confidence score (0.0-1.0).

        Example:
            >>> extractor = DependencyExtractor(scope, resolver, config)
            >>> add_node = sqlglot.parse_one("SELECT a + b").expressions[0]
            >>> columns_conf = extractor._extract_source_columns_with_confidence(add_node)
            >>> len(columns_conf) >= 2
            True
        """
        # Use ExpressionVisitor to get columns
        visitor = ExpressionVisitor(self.resolver, debug=False)
        columns = visitor.visit(expr)

        # Deduplicate columns first
        unique_columns = deduplicate_columns(columns)

        # Build confidence map for unique columns
        confidence_map: dict[ColumnRef, float] = {}
        context = expr.sql() if hasattr(expr, "sql") else None

        # Get confidence for each unique column
        # Since columns are already resolved, we can estimate confidence
        # based on how they were resolved (explicit prefix, schema match, etc.)
        for col in unique_columns:
            # Estimate confidence based on resolution method
            # Explicit table prefix: high confidence
            # Single table: high confidence
            # Schema match: high confidence
            # Ambiguous resolution: lower confidence
            if hasattr(self.resolver, "resolve_column_with_inference"):
                try:
                    # Re-resolve to get confidence (this is safe since column is already resolved)
                    # Pass None as table_qualifier to let resolver infer
                    _, confidence = self.resolver.resolve_column_with_inference(
                        col.column, None, context
                    )
                except Exception:
                    # If inference fails, check if we have explicit table info
                    # If column has explicit table info, assume high confidence
                    confidence = 0.95 if col.table and col.table != "__OUTPUT__" else 1.0
            else:
                # No enhanced method available, use default confidence
                confidence = 1.0

            confidence_map[col] = confidence

        return confidence_map

    def _determine_expression_type(
        self, expr: sqlglot.Expression
    ) -> ExpressionType:
        """Determine the type of an expression.

        This method determines the expression type based on:
        1. Pure column reference -> DIRECT
        2. Contains arithmetic operations -> COMPUTED
        3. Contains function calls -> FUNCTION
        4. CASE expression -> CASE
        5. Aggregate function -> AGGREGATION (v0.1: raise error)
        6. Window function -> WINDOW (v0.1: raise error)

        Args:
            expr: SELECT expression node.

        Returns:
            ExpressionType enum value.

        Raises:
            NotImplementedError: If aggregate or window functions are detected.

        Example:
            >>> extractor = DependencyExtractor(scope, resolver, config)
            >>> col_node = sqlglot.parse_one("SELECT id").expressions[0]
            >>> expr_type = extractor._determine_expression_type(col_node)
            >>> expr_type == ExpressionType.DIRECT
            True
        """
        # Check for aggregate function
        if is_aggregate_function(expr):
            raise NotImplementedError(
                "Aggregate functions are not supported in v0.1. "
                f"Expression: {expr.sql() if hasattr(expr, 'sql') else str(expr)}"
            )

        # Check for window function
        if is_window_function(expr):
            raise NotImplementedError(
                "Window functions are not supported in v0.1. "
                f"Expression: {expr.sql() if hasattr(expr, 'sql') else str(expr)}"
            )

        # Handle alias: check the actual expression
        if isinstance(expr, expressions.Alias):
            return self._determine_expression_type(expr.this)

        # Handle column reference
        if isinstance(expr, expressions.Column):
            return ExpressionType.DIRECT

        # Handle CASE expression
        if isinstance(expr, expressions.Case):
            return ExpressionType.CASE

        # Handle function call
        if contains_function(expr):
            return ExpressionType.FUNCTION

        # Handle binary operations
        if contains_binary_op(expr):
            return ExpressionType.COMPUTED

        # Default: treat as direct
        return ExpressionType.DIRECT

    def _get_expression_text(self, expr: sqlglot.Expression) -> Optional[str]:
        """Get formatted expression text.

        This method extracts the original SQL text for an expression
        and formats it (removes extra whitespace) for traceability.

        Args:
            expr: SELECT expression node.

        Returns:
            Formatted expression text, or None if not available.

        Example:
            >>> extractor = DependencyExtractor(scope, resolver, config)
            >>> add_node = sqlglot.parse_one("SELECT a + b").expressions[0]
            >>> text = extractor._get_expression_text(add_node)
            >>> "a + b" in text or "a+b" in text
            True
        """
        if hasattr(expr, "sql"):
            sql_text = expr.sql()
            # Normalize whitespace: replace multiple spaces with single space
            sql_text = re.sub(r"\s+", " ", sql_text).strip()
            return sql_text
        return str(expr) if expr else None

    def _is_star_expression(self, expr: sqlglot.Expression) -> bool:
        """Check if an expression is a Star expression (SELECT * or SELECT table.*).

        Args:
            expr: SELECT expression node.

        Returns:
            True if the expression is a Star expression, False otherwise.

        Example:
            >>> extractor = DependencyExtractor(scope, resolver, config)
            >>> star_node = sqlglot.parse_one("SELECT *").expressions[0]
            >>> extractor._is_star_expression(star_node)
            True
        """
        # Check if it's a direct Star node
        if isinstance(expr, expressions.Star):
            return True
        
        # Check if it's a Column node containing a Star (SELECT table.*)
        if isinstance(expr, expressions.Column):
            if hasattr(expr, "this") and isinstance(expr.this, expressions.Star):
                return True
            # Also check if it's a Star wrapped in an Identifier
            if hasattr(expr, "this") and hasattr(expr.this, "this") and isinstance(expr.this.this, expressions.Star):
                return True
        
        # Check if it's an Alias wrapping a Star
        if isinstance(expr, expressions.Alias):
            if hasattr(expr, "this") and isinstance(expr.this, expressions.Star):
                return True
            if hasattr(expr, "this") and isinstance(expr.this, expressions.Column):
                if hasattr(expr.this, "this") and isinstance(expr.this.this, expressions.Star):
                    return True
        
        return False

